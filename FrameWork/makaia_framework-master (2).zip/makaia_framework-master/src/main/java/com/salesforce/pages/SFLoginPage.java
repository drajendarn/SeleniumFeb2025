package com.salesforce.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class SFLoginPage extends ProjectSpecificMethods {

	public SFLoginPage enterUserName(String uname)
	{
		clearAndType(locateElement(Locators.ID, "username"), uname);
		reportStep(uname + "Username entered successfully","pass");
		return this;
	}
	
	public SFLoginPage enterPassword(String password)
	{

		clearAndType(locateElement(Locators.ID, "password"), password);
		reportStep(password + "Password Entered successfully","pass");
		return this;
	}
	public SFHomePage clickLogin() {
		click(locateElement(Locators.XPATH, "//input[@id='Login']"));
		reportStep("Login button clicked successfully","pass");
		return new SFHomePage();
	}
}
