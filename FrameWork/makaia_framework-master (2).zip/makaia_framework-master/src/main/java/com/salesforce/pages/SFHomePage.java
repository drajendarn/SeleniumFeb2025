package com.salesforce.pages;

import javax.swing.JScrollBar;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class SFHomePage extends ProjectSpecificMethods{
	
	/*//To READ IT FROM CONFIG FILES
	 * FileInputStream config = new
	 * FileInputStream("./src/main/resources/config.properties"); prop = new
	 * Properties(); prop.load(config); public LoginPage enterPassword() {
	 * clearAndType(locateElement(Locators.ID, "password"),
	 * prop.getProperty("password"));
	 * reportStep("Password entered successfully","pass"); return this; }
	 */
	
    public SFHomePage clickToggle() {
    	click(locateElement(Locators.XPATH,"//div[@class='slds-icon-waffle']"));
    	reportStep("Toggle menu clicked successfully","pass");
    	return this;
    }
    public SFHomePage clickViewAll() {
    	click(locateElement(Locators.XPATH,"//button[text()='View All']"));
    	reportStep("View All option clicked successfully","pass");
    	return this;
    }
    
    public SFIndividualHomePage clickIndividualLink() {
    	//JavascriptExecutor js=(JavascriptExecutor) getDriver();
    	
       	WebElement salesLink = locateElement(Locators.XPATH,"//p[text()='Individuals']/ancestor::a");
       	executeTheScript("arguments[0].scrollIntoView(true);",salesLink);
       //	js.executeScript("arguments[0].scrollIntoView(true);", salesLink);
       	clickUsingJs(salesLink);
    	reportStep("Individual link clicked successfully","pass");
    	return new SFIndividualHomePage();
    }

}
