package com.salesforce.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class SFIndividualHomePage extends ProjectSpecificMethods
{
	
	public SFIndividualModal clickNewIndividual()
	{
		click(locateElement(Locators.XPATH,"//div[@title='New']"));
    	reportStep("New button clicked successfully","pass");
    	return new SFIndividualModal();
	}

}
