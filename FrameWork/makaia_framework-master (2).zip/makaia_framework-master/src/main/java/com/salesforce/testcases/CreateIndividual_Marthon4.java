package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.leaftaps.pages.LoginPage;
import com.salesforce.pages.SFLoginPage;

public class CreateIndividual_Marthon4 extends ProjectSpecificMethods{

	
	@BeforeTest
	public void setValues() {
		testcaseName = "Create Individual";
		testDescription ="Verify Create Individual functionality with positive data";
		authors="Divya";
		category ="Smoke";
		excelFileName="Login";
	}
	
	@Test(dataProvider = "fetchData")
	public void createIndividual(String uname,String pass) {
		SFLoginPage lp=new SFLoginPage();
	//lp.enterUsername(uname).enterPassword(pass).clickLogin();
		lp.enterUserName(uname)
		.enterPassword(pass)
		.clickLogin()
		.clickToggle()
		.clickViewAll()
		.clickIndividualLink()
		.clickNewIndividual()
		.enterLastName()
		.clickSaveButton()
		.verifyIndividual();
	}
}
