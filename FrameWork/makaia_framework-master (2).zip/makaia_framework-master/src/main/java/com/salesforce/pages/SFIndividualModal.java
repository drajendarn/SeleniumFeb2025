package com.salesforce.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class SFIndividualModal extends ProjectSpecificMethods {
	
	public SFIndividualModal enterLastName()
	{
		clearAndType(locateElement(Locators.XPATH, "//input[@placeholder='Last Name']"), "Divya");
		reportStep("LastName entered successfully","pass");
		return this;
	}

	public SFViewIndividual clickSaveButton()
	{
	click(locateElement(Locators.XPATH,"//button[@title='Save']"));	
		reportStep("LastName entered successfully","pass");
		return new SFViewIndividual();
		
	}
	
}
