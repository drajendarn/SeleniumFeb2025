package com.salesforce.pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class SFViewIndividual extends ProjectSpecificMethods{
	
	public SFViewIndividual verifyIndividual()
	{
		
		String toastMessage=locateElement(Locators.XPATH,"//span[@class='toastMessage slds-text-heading--small forceActionsText']").getText();
	    System.out.println(toastMessage);
        Assert.assertTrue(toastMessage.contains("ndividual \"Divya\" was created."),"Toast message displayed as expected ");
        return this;
	}
}
